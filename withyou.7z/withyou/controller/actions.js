import express from 'express';
import mongoose from 'mongoose';
import Information from '../models/information.js';
import bcryptjs from 'bcryptjs';
import jwt  from 'jsonwebtoken';

//דרל ה router יכולים לגשת ל postmen
const router = express.Router();

router.get('/getAccounts', async(request,response) => {

    //const account = await Information.find();
    const account = await Information.find();
    response.status(200).json({
        account: account
    })
})

// router.post('/createNewAccount', async(request,response) => {
//    //create object id
//     const id = new mongoose.Types.ObjectId();
//    //get data from postmen
//    const {Name,PhoneNumber,Password,avatar} = request.body;             
//    //new ducoment in information collection
//    const _information = new Information({
//       _id: id,
//       Name:Name,
//       PhoneNumber: PhoneNumber,
//       Password: Password,
//       avatar: avatar
//    })
//    _information.save()
//    .then(results => {
//        return response.status(200).json({
//           message: results
//        })
//    })
//    .catch(error => {
//       return response.status(500).json({
//         message: error.message
//       })
//    })

// })

router.post('/register', async(request,response) => {
    //get account info from body
    const {Name,PhoneNumber,Password,avatar} = request.body;
    //check if phoneNumber exist
    const isAccountExist = await Information.findOne({PhoneNumber: PhoneNumber});
    if(isAccountExist){
        return response.status(200).json({
            message: 'Account Exist'
        });
    }
    //password crypt מוצפנת
    const hash_password = await bcryptjs.hash(Password,10);//hash פונקציה מצפינה
    //create user in db
    const id = new mongoose.Types.ObjectId();
    const _account = new Information({
        _id: id,
        Name: Name,
        PhoneNumber: PhoneNumber,
        Password: hash_password,
        avatar: avatar
    })
    _account.save()
    .then(result => {
         return response.status(200).json({
            result: result
         })
    })
    .catch(error => {
         return response.status(500).json({
            message: error.message
         })
    })


})

router.post('/login', async(request,response) => {
    //get account info from client
    const {PhoneNumber,Password} =  request.body;
    //Check if user exist by PhoneNumber
    Information.findOne({PhoneNumber: PhoneNumber})
    .then(async account => {
        if(!account){
            return response.status(200).json({
                message: 'Account not Exist'
            });
        }
        //Compare password
        const isMatch = await bcryptjs.compare(Password, account.Password);
        if(!isMatch){
           return response.status(200).json({
            message: 'Password not match'
           });
        }
         //generate jwt token
        const dataToToken = {
            _id: account._id,
            name: account.Name,
            PhoneNumber: account.PhoneNumber,
            avatar: account.avatar 
        }
        const token = await jwt.sign({dataToToken}, process.env.JWT_KEY, {expiresIn:'30d'});

        //response

        return response.status(200).json({
            message: account,
            token: token
        })
    })
    .catch(error => {
        return response.status(500).json({
           message: error.message
        })
    })
})

export default router;//מיצאים את כל ה routers

